# ai_module.py
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_chroma import Chroma
import google.genai as genai
from config import CHROMA_DIR, API_KEY
from pydantic import BaseModel
from typing import List, Optional

# Initialize Client
client = genai.Client(api_key=API_KEY)

# Embedding model for search
embedding_model = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")


class QuestionResponse(BaseModel):
    answer: str
    sources: List[str]


def ask_question(question: str, vectordb: Chroma, k: int = 3, source: Optional[str] = None) -> QuestionResponse:
    """Answer a question using the given vector DB. Optionally filter by source filename."""
    # Build search kwargs with filter if source provided
    search_kwargs = {"k": k}
    if source:
        # Ensure the filter matches the metadata structure stored in pdf_handler
        search_kwargs["filter"] = {"source_file": source}

    try:
        results = vectordb.similarity_search(question, **search_kwargs)
    except Exception as e:
        return QuestionResponse(answer=f"Error searching database: {str(e)}", sources=[])

    if not results:
        return QuestionResponse(answer="No relevant information found in the uploaded PDFs.", sources=[])

    context = "\n\n".join([doc.page_content for doc in results])

    prompt = f"""
Answer the question using the context below. Be concise and accurate.

Context:
{context}

Question: {question}

Answer:
"""
    try:
        response = client.models.generate_content(model="gemini-2.5-flash", contents=prompt)
        answer_text = response.text
    except Exception as e:
        answer_text = f"Error generating answer from AI: {str(e)}"

    sources = list(set(doc.metadata.get("source_file", "unknown") for doc in results))
    return QuestionResponse(answer=answer_text, sources=sources)


def generate_quiz_from_context(chunks: List[str]) -> str:
    """
    Generate quiz questions based on specific text chunks.
    Useful for adaptive quiz generation on weak areas.
    """
    context = "\n\n".join(chunks)

    if not context:
        return "Error: No context provided to generate quiz."

    prompt = f"""
    You are an expert tutor. Create 3 multiple choice questions based ONLY on the provided context.

    Context:
    {context}

    Instructions:
    1. Create a question.
    2. Provide 4 options (a, b, c, d).
    3. Indicate the correct answer.
    """

    try:
        response = client.models.generate_content(model="gemini-2.5-flash", contents=prompt)
        return response.text
    except Exception as e:
        return f"Error generating quiz: {str(e)}"