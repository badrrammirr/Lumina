# Backend/main.py
import os
import shutil
import json
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, UploadFile, File, Body
from fastapi.middleware.cors import CORSMiddleware

# Internal imports
from ai_module import ask_question, QuestionResponse, client
from pdf_handler import build_vector_database, get_vector_db
from config import PDF_FOLDER, CHROMA_DIR
from preformance_analyzer import analyze_results
from adapt_quiz import generate_adaptive_quiz
from quiz_generator import generate_quiz


# --- 1. STARTUP LOGIC (Reset Data on Start) ---
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Code runs on startup
    print("🚀 Starting server... Resetting data folders...")

    # 1. Clear PDF Folder
    if PDF_FOLDER.exists():
        shutil.rmtree(PDF_FOLDER)
    PDF_FOLDER.mkdir(parents=True, exist_ok=True)
    print(f"✅ Cleared: {PDF_FOLDER}")

    # 2. Clear Chroma Database
    if CHROMA_DIR.exists():
        shutil.rmtree(CHROMA_DIR)
    print(f"✅ Cleared: {CHROMA_DIR}")

    # 3. Clear processed files log
    processed_log = Path(__file__).parent / "processed_pdfs.json"
    if processed_log.exists():
        processed_log.unlink()

    print("🟢 Startup complete. Ready for new uploads.")

    yield  # Server runs here

    # Code runs on shutdown (optional)
    print("🔴 Server shutting down.")


# --- 2. APP INITIALIZATION ---
app = FastAPI(title="AI Tutor Backend", lifespan=lifespan)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- 3. ENDPOINTS ---

@app.post("/generate_quiz")
def create_quiz(filename: str):
    """Generate a quiz from a specific PDF file."""
    try:
        vectordb = get_vector_db()
        docs = vectordb.similarity_search("", k=10, filter={"source_file": filename})

        if not docs:
            raise HTTPException(status_code=404, detail="No content found for this PDF.")

        context = "\n".join([d.page_content for d in docs])
        quiz_text = generate_quiz(context, client)
        return {"quiz": quiz_text, "source_file": filename}
    except Exception as e:
        print(f"Error generating quiz: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ask", response_model=QuestionResponse)
def ask_endpoint(question: str, k: int = 3, source: str = None):
    try:
        vectordb = get_vector_db()
        return ask_question(question, vectordb, k, source)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/upload_pdf")
async def upload_pdf(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are allowed.")
    file_path = os.path.join(PDF_FOLDER, file.filename)
    try:
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
        print(f"{file.filename} uploaded.")
        build_vector_database()
        return {"message": f"{file.filename} uploaded and database updated."}
    except Exception as e:
        print("Error in upload_pdf:", e)
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/pdf/{filename}")
async def delete_pdf(filename: str):
    """Delete a specific PDF and its vectors."""
    file_path = os.path.join(PDF_FOLDER, filename)

    # 1. Delete file from disk
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found on disk.")

    try:
        os.remove(file_path)
    except Exception as e:
        print(f"Error deleting file: {e}")
        raise HTTPException(status_code=500, detail="Error deleting file from disk.")

    # 2. Delete vectors from Chroma
    try:
        vectordb = get_vector_db()
        vectordb._collection.delete(where={"source_file": filename})
        print(f"Deleted vectors for {filename}")
    except Exception as e:
        print(f"Warning: Could not delete vectors for {filename}: {e}")
        # Continue even if vector deletion fails (e.g. DB empty)

    # 3. Update processed_pdfs.json
    try:
        proc_file = Path(__file__).parent / "processed_pdfs.json"
        if proc_file.exists():
            with open(proc_file, 'r') as f:
                processed = set(json.load(f))

            if filename in processed:
                processed.remove(filename)
                with open(proc_file, 'w') as f:
                    json.dump(list(processed), f)
    except Exception as e:
        print(f"Error updating processed list: {e}")

    return {"message": f"{filename} deleted successfully."}


@app.post("/analyze_results")
def analyze_student(results: list = Body(...)):
    try:
        weak_chunks = analyze_results(results)
        return {"weak_chunks": weak_chunks}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/generate_adaptive_quiz")
def generate_adaptive_quiz_endpoint(weak_chunks: list = Body(...)):
    if not weak_chunks:
        raise HTTPException(status_code=400, detail="No weak chunks provided.")
    try:
        vectordb = get_vector_db()
        questions = generate_adaptive_quiz(weak_chunks, vectordb)
        return {"questions": questions}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/pdfs")
def list_pdfs():
    files = [f for f in os.listdir(PDF_FOLDER) if f.endswith(".pdf")]
    return {"pdfs": files}


@app.get("/")
def root():
    return {"message": "AI Tutor Backend Running"}


@app.get("/status")
def status():
    # Check if DB directory exists and is not empty
    db_ready = CHROMA_DIR.exists() and any(CHROMA_DIR.iterdir())
    return {"status": "Database ready." if db_ready else "Database not found."}