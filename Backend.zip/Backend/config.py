# backend/config.py
from pathlib import Path


BASE_DIR = Path(__file__).parent

PDF_FOLDER = BASE_DIR / "PDFS"
CHROMA_DIR = BASE_DIR / "chroma_db"

CHUNK_SIZE = 800
CHUNK_OVERLAP = 200
API_KEY = "AIzaSyC6JEGN_vGz32UaFbT6w1qrcWcihcco1-4"
NUM_QUIZ_QUESTIONS = 10