# adapt_quiz.py
from ai_module import generate_quiz_from_context
# You no longer need to import client here

def generate_adaptive_quiz(weak_chunks, vectordb):
    context = []

    for cid in weak_chunks:
        # Try to find the content
        docs = vectordb.similarity_search(str(cid), k=1)
        for d in docs:
            context.append(d.page_content)

    if not context:
        return "Could not find relevant content for the provided weak areas."

    # Call the updated function from ai_module
    return generate_quiz_from_context(context)